//
//  main.c
//  OpenMPIExamples
//
//  Created by chang on 3/11/11.
//  Copyright 2011 WMU. All rights reserved.
//

#include <stdio.h>
#include <mpi.h>

int main (int argc, char * argv[])
{

    int tid, numtasks, i, data;
    
    MPI_Status mpistatus;
    
    MPI_Init(&argc, &argv);
    
    MPI_Comm_size(MPI_COMM_WORLD, &numtasks);
    MPI_Comm_rank(MPI_COMM_WORLD, &tid);
    
    printf("Hello World from %i of %i\n", tid, numtasks);
    if (tid == 0)
    {
        data = 100;
        for (i = 1; i < numtasks; i++)
        {
            MPI_Send(&data, 1, MPI_INT, i, 55, MPI_COMM_WORLD);
        }
    } else {
        MPI_Recv(&data, 1, MPI_INT, 0, 55, MPI_COMM_WORLD, &mpistatus);
        printf("Process ID %i: received data %i\n", tid, data);
    }
    
    MPI_Finalize();
    
    return 0;
}

