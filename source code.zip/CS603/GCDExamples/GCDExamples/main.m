//
//  main.m
//  GCDExamples
//
//  Created by chang on 3/11/11.
//  Copyright 2011 WMU. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <dispatch/dispatch.h>

#define MAX(a, b)   ((a) > (b) ? (a) : (b))
#define MIN(a, b)   ((a) < (b) ? (a) : (b))

int main(int argc, char *argv[])
{
    const int N = 1000;
    const int BLURRADIUS = 7;
    float originalImage[N*N], blurredImage[N*N];
    
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_apply(N, queue, ^(size_t row) {
        int col, i, j;
        for (col = 0; col < N; ++col)
        {
            int pixIndex = row * N + col;
            blurredImage[pixIndex] = 0.0f;
            for (i = MAX(0, row-BLURRADIUS); i < MIN(row+BLURRADIUS, N); ++i)
            {
                for (j = MAX(0, row-BLURRADIUS); j < MIN(row+BLURRADIUS, N); ++j)
                {
                    int blurPixIndex = i * N + j;
                    float distance = (i - row) * (i - row) + (j - col) * (j - col);
                    distance = sqrt(distance);
                    blurredImage[pixIndex] += exp(-distance*distance) * originalImage[blurPixIndex];
                }
            }
        }
    });
    
    return 0;
}

/*
static uint32_t ntimers = 0;
static dispatch_queue_t ntimer_serial = NULL;

static dispatch_queue_t print_serial = NULL;

int main(int argc, char *argv[])
{
    dispatch_queue_t main_q;
    int i;
    
    print_serial = dispatch_queue_create("Print Queue", NULL);
    ntimer_serial = dispatch_queue_create("N Timers Queue", NULL);
    
    main_q = dispatch_get_main_queue();
    
    for (i = 1; i < argc; i+= 2)
    {
        uint64_t duration;
        dispatch_source_t src;
        __block int32_t count;
        
        duration = atoll(argv[i]) * NSEC_PER_SEC;
        count = atoi(argv[i+1]);
        src = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, main_q);
        dispatch_source_set_timer(src, 0, duration, 0);
        
        dispatch_source_set_event_handler(src, ^{
            count--;
            dispatch_async(print_serial, ^{ printf("%s second timer     count %u\n", argv[i], count); });
            
            if (count == 0)
            {
                dispatch_source_cancel(src);
                dispatch_release(src);
                dispatch_sync(ntimer_serial, ^{ ntimers--; });
            }
            
            if (ntimers == 0)
            {
                dispatch_sync(print_serial, ^{ printf("All timers finished. Goodbye\n"); });
                exit(0);
            }
        });
        
        dispatch_sync(ntimer_serial, ^{ ntimers++; });
        dispatch_resume(src);
    }
    
    dispatch_main();
    return 0;
}
 */
