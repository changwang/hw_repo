//
//  main.c
//  OpenMPExamples
//
//  Created by chang on 3/11/11.
//  Copyright 2011 WMU. All rights reserved.
//

#include <stdio.h>
#include <omp.h>

#define N           1000
#define CHUNKSIZE   100

int main (int argc, const char * argv[])
{
    
    /* directive parallel 
     int nthreads, tid;
   
#pragma omp parallel private(tid) num_threads(10)
{
    tid = omp_get_thread_num();
    printf("Hello World from thread = %d\n", tid);
    if (tid == 0)
    {
        nthreads = omp_get_num_threads();
        printf("Number of threads = %d\n", nthreads);
    }
}   */
    
    /* directive for */
    int i, chunk;
    float a[N], b[N], c[N];
    
    for (i = 0; i < 1000; i++)
    {
        a[i] = b[i] = i * 1.0;
    }
    chunk = CHUNKSIZE;
    
#pragma omp parallel shared(a, b, c, chunk) private(i)
    {
#pragma omp for schedule(dynamic, chunk) nowait

        for (i = 0; i < N; i++)
        {
            c[i] = a[i] + b[i];
        }
    }
    
    for (i = 0; i < N; i++)
    {
        printf("%g\n", c[i]);
    }

    
    /* directive section */
    int i;
    float a[N], b[N], c[N], d[N];
    
    for (i = 0; i < N; i++)
    {
        a[i] = i * 1.5;
        b[i] = i + 22.35;
    }
    
#pragma omp parallel shared(a, b, c, d) private(i)
    {
#pragma omp sections nowait
        {
#pragma omp section
            for (i = 0; i < N; i++)
            {
                c[i] = a[i] + b[i];
            }
            
#pragma omp section
            for (i = 0; i < N; i++)
            {
                d[i] = a[i] * b[i];
            }
        }
    }
    
    for (i = 0; i < N; i++)
    {
        printf("%g\t%g\n", c[i], d[i]);
    }

    
    /* directive critical */
     
    int x;
    x = 0;
#pragma omp parallel shared(x)
    {
#pragma omp critical
        x = x + 1;
    }

    return 0;
}

